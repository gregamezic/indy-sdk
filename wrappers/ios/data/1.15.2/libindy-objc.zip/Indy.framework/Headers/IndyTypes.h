//
//  IndyTypes.h
//  libindy
//

typedef SInt32 IndyHandle;
